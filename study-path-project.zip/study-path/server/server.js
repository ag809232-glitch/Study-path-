const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const clientDist = path.join(__dirname, '..', 'client', 'dist');

app.use(express.json({ limit: '1mb' }));
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, app: 'Study Path API' });
});
app.use(express.static(clientDist));
app.get('*', (_req, res) => {
  res.sendFile(path.join(clientDist, 'index.html'), (err) => {
    if (err) res.status(404).send('Build the React app first.');
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Study Path server listening on ${PORT}`);
});
