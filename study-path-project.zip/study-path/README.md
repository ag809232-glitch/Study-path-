# Study Path

A mobile-friendly education website starter with a React frontend and Node.js/Express backend.

## Run locally
1. Install Node.js.
2. Run `npm run install:all`
3. Run `npm run build`
4. Run `npm start`
5. Open http://localhost:3000

Photo and signature previews are handled in the browser; this starter does not upload or permanently store personal files.
